/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.quizz01;

/**
 *
 * @author 1781621
 */
public class Livres {
    private String titre, nom, prenom, categorie;
    private int isbn;
    private String code;

    public Livres() {
        this("Programmer en c++", "Delannoy", "Claude", "Programmation", 1234, "DeC1Pr34");
    }

    public Livres(String titre, String nom, String prenom, String categorie, int isbn, String code) {
        this.titre = titre;
        this.nom = nom;
        this.prenom = prenom;
        this.categorie = categorie;
        this.isbn = isbn;
        this.code = code;
    }

    public String getTitre() {
        return titre;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getCategorie() {
        return categorie;
    }

    public int getIsbn() {
        return isbn;
    }

    public String getCode() {
        return code;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setCode(String code) {
        this.code = code;
    }
    
    public void afficherLivres() {
        System.out.println("la liste des livres: \ntitre = " + this.titre + "\ncatégorie = " + this.categorie + "\nisbn =  " 
                + this.isbn + "\nnomAuteur = " + this.nom + "\nprenomAuteur = " + this.prenom + "\ncode = " 
                + this.code);
    }
    
    
}
