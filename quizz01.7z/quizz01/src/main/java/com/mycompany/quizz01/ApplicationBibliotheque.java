/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.quizz01;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author 1781621
 */
public class ApplicationBibliotheque {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner lire = new Scanner(System.in);
       

        String menu = "Menu\n"
                + "1- pour ajouter un livre\n"
                + "2- pour afficher la liste de livres\n"
                + "0- pour quitter";
        Livres livre = new Livres();
//        ArrayList<Livres>listeLivres = new ArrayList<>();
//        listeLivres = add(new Livres("Programmer en c++", "Delannoy", "Claude", "Programmation", 1234, "DeC1Pr34"));

        int choix;
        boolean test = false;

        do {
            System.out.println(menu);
            choix = lire.nextInt();
            System.out.println(menu);
            switch (choix) {
                case 0:
                    test = true;
                    break;
                case 1:
                    System.out.println("Votre choix est: 1");
                System.out.print("entrez le titre: ");
                livre.setTitre(lire.nextLine());
                System.out.print("entrez le titre: ");
                livre.setCategorie(lire.nextLine());
                System.out.print("entrez le titre: ");
                livre.setNom(lire.nextLine());
                System.out.print("entrez le titre: ");
                livre.setPrenom(lire.nextLine());
                System.out.print("entrez le titre: ");
                livre.setIsbn(lire.nextInt());
                    test = false;

                    break;
                case 2:
                    livre.afficherLivres();
                    test = false;
                    break;

                default:
                    throw new AssertionError("Le numéro choisi n'est pas dans le menu");
            }
        } while (!test);

    }

}
